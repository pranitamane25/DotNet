namespace AboutUsModel
{
    public class AboutUsModel
    {
        public void OnGet()
        {

        }
    }
}