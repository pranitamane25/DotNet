namespace WebApp.Pages;
public class ContactModel
{
    public void OnGet()
    {

    }
}