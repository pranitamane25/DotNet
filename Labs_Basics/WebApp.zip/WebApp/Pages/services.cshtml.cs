namespace WebApp.Pages.pages_services
{
    public class servicesModel
    {
        public void OnGet()
        {

        }
    }
}