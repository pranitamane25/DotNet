namespace SOLID_principles.Publisher.Operations;
public interface IWithdrawOperation
{
    void Withdraw(double amount );
}