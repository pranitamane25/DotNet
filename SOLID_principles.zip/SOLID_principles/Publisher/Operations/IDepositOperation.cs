namespace SOLID_principles.Publisher.Operations;
public interface IDepositOperation
{
    void Deposit(double amount);
}