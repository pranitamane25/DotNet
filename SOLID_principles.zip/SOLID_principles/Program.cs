﻿using System;
using SOLID_principles.Listeners;
using SOLID_principles.Services;
public class Program
{
    public static void Main(string[] args)
    { 
        INotificationService notificationService = new SMSService();

        Account account = new Account(5000, notificationService);
        account.AddListener( new AccountsDepartment());
        account.Withdraw(4500);
        account.Deposit(300000);
    }
}